list_report_all.php
<?php
	// ส่วนการรับเงงื่อนไข เพื่อการสืบค้นข้อมูล
	include("../../config/config.php");
	$dd = pg_escape_string($_REQUEST['txt_voucher']); // เลขที่ใบสำคัญรับ
	$s_date = pg_escape_string($_REQUEST['s_date']); // วันที่ ที่ต้องการสืบค้นข้อมูล
	$s_month = pg_escape_string($_REQUEST['s_month']); // เดือน ที่ต้องการสืบค้นข้อมูล
	$s_year = pg_escape_string($_REQUEST['s_year']); // ปี ที่้ต้องการสืบค้นข้อมูล
	$s_datefrom = pg_escape_string($_REQUEST['s_datefrom']); // วันที่เริิ่มต้น ของต้องการสืบค้นข้อมูล
	$s_dateto = pg_escape_string($_REQUEST['s_dateto']); // วันที่สุดท้าย ของการสืบค้นข้อมูล
	$s_sel_year = pg_escape_string($_REQUEST['s_sel_year']);//ปีที่ค้นหา
	$s_valuee = pg_escape_string($_REQUEST['s_value']); // ค่าตัวแปรจากการเลือก  วิธีการสืบค้นข้อมูลในเงื่อนไขหลัก
	$s_detail = pg_escape_string($_REQUEST['s_detail']); // ส่วนของ ตามรายละเอียด ที่ใช้สืบค้นข้อมูล
	$s_cancel = pg_escape_string($_REQUEST['s_cancel']);  // สถานะการเลือก  "แสดงรายการที่ยกเลิก/รายการปรับปรุงยกเลิก "
	$s_purpose_idx = pg_escape_string($_REQUEST['s_purpose_idx']);  // เลขรหัสจุดประสงค์ ของใบสำคัญ
	$s_chk_detail = pg_escape_string($_REQUEST['s_chk_detail']); // สถานะการเลือก  "ตามรายละเอียด "
	$s_chk_purpose = pg_escape_string($_REQUEST['s_chk_purpose']); // สถานะการเลือก "จุดประสงค์"
	
	// Call Function เพื่อแสดง   รายการใบสำคัญจ่าย 
	require('list_report_payment_voucher.php');
    
    // Call Function เพื่อแสดง    รายการใบสำคัญรับ
	require('list_report_receive_voucher.php');

	// Call Function เพื่อแสดง รายการใบสำคัญรายวันทั่วไป 	
	require('list_report_journal_voucher.php');
	
	// Call Functiion เพื่อแสดง  ใบสำคัญจ่ายที่รออนุมัติยกเลิก
	require('payment_Voucher_approve_wait.php');
	// Call Function เพื่อแสดง ใบสำคัญรับที่รออนุมัติยกเลิก 
	require('receive_Voucher_approve_wait.php');
	// Call Function เพื่อแสดง  ใบสำคัญรายวันทั่วไปที่รออนุมัติยกเลิก
	require('journal_Voucher_approve_wait.php');

?>
<script>
   /*$("#list_voucher").load("list_report_payment_voucher.php",{
			txt_voucher:tv,
			s_date:date1,
			s_month:month,
			s_year:year,
			s_datefrom:datefrom,
			s_dateto:dateto,
			s_sel_year:sel_year,
			s_value:searchValue,
			s_cancel:cancel,
			s_detail:detail,
			s_purpose_idx:purpose_idx,
			s_chk_detail:chk_sel_detail,
			s_chk_purpose:chk_sel_purpose
			});   
    */
</script>