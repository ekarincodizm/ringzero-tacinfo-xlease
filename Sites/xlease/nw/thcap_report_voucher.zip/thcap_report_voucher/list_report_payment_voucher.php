<BR>list_Report_Payment_Voucher.php
ส่วนการแศดงใบสำคัญรับ
<?php]
	include("../../config/config.php");
	echo $txt_voucher;

?>